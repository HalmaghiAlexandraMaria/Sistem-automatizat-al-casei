#include "iRoom.h"
#ifndef HOUSE_H
#define HOUSE_H

class House{
    private:
    std::vector <IRoom*> rooms; // parametru ca si pointer catre un obiect

    public:
    void addRoom(IRoom* room){ //parametru ca referinta la un obiect
        rooms.push_back(room);
        std::cout<<"Camera adaugata\n";
    };
    void removeRoom(int i){
        if (i >= rooms.size()){
            std::cout<<"[EROARE]Indexul de stergere este prea mare\n";
        }
        else{
            rooms.erase(rooms.begin() + i);
            std::cout<<"Camera eliberata\n";
        }
        //vector.begin() returneaza un iterator catre primul element
        //vector.erase(i) sterge containerul la iteratorul i
    };
    void collectRoomData(){
        for (int i = 0; i < rooms.size() ; i++){
            rooms.at(i)->updateRoom();
        }
        std::cout<<"Masurari salvate\n";
    };
    void viewRoomData(){
        for (int i = 0; i < rooms.size() ; i++){
            rooms.at(i)->readRoom();
        }
    };
};
#endif