#include "Library/House.h"

int main(){
    std::cout<<"Hello\n";
    //std::cout<<presiune.generatePresure()<<"\n";
    House casa;
    casa.addRoom(new IBedroom);
    casa.addRoom(new IBathroom);
    casa.addRoom(new IKitchen);
    casa.addRoom(new ILiving);
    casa.viewRoomData();
    casa.collectRoomData();
    return 0;
}
